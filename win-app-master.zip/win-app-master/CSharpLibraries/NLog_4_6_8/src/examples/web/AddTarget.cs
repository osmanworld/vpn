static void Main(string[] args)
{
    TargetFactory.AddTarget("MyFirst", typeof(MyNamespace.MyFirstTarget));

    // start logging here
}
