## NLog 4.6.8

NLog 4.6.8 is the logger used by the Windows client of ProtonVPN.

NLog GitHub: https://github.com/NLog/NLog


## Changes made

The NLog 4.6.8 source code was downloaded from NLog GitHub and the Assembly Version was changed from 4.0.0 to 4.6.8.

No code was changed, just built with a different Assembly Version.
